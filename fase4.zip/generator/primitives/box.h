#ifndef GENERATOR_BOX_H
#define GENERATOR_BOX_H
#define REGULAR 1
#define INVERT -(REGULAR)

int box(char * file_path, float x, float y, float z, int div);

#endif //GENERATOR_BOX_H
