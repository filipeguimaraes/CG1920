#ifndef GENERATOR_CONE_H
#define GENERATOR_CONE_H

void cone(char * file, float h, float r, float slices, float stacks);


#endif //GENERATOR_CONE_H
