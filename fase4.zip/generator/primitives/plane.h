#ifndef GENERATOR_PLANE_H
#define GENERATOR_PLANE_H

int plane(char * file_path, float a);


#endif //GENERATOR_PLANE_H
