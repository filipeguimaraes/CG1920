#ifndef GENERATOR_SPHERE_H
#define GENERATOR_SPHERE_H

void sphere(char * file, float raio, int slices, int stacks);

#endif //GENERATOR_SPHERE_H
